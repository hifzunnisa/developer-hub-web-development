import { useState } from "react";
import { ExternalLink, Code, Smartphone, Brain, Video } from "lucide-react";

export function Portfolio() {
  const [activeFilter, setActiveFilter] = useState("all");

  const categories = [
    { id: "all", label: "All Projects" },
    { id: "web", label: "Web Development" },
    { id: "mobile", label: "Mobile Apps" },
    { id: "ai", label: "AI Solutions" },
    { id: "marketing", label: "Marketing" },
  ];

  const projects = [
    {
      title: "E-Commerce Platform",
      category: "web",
      description: "A full-featured online shopping platform with integrated payment processing and inventory management.",
      image: "https://images.unsplash.com/photo-1661956602116-aa6865609028?w=800&h=600&fit=crop",
      tags: ["React", "Node.js", "MongoDB"],
      icon: Code,
    },
    {
      title: "Fitness Tracking App",
      category: "mobile",
      description: "iOS and Android app for tracking workouts, nutrition, and health metrics with AI-powered insights.",
      image: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&h=600&fit=crop",
      tags: ["React Native", "Firebase", "AI"],
      icon: Smartphone,
    },
    {
      title: "AI Content Generator",
      category: "ai",
      description: "Advanced AI platform for generating marketing content, blog posts, and social media captions.",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=600&fit=crop",
      tags: ["Python", "OpenAI", "Next.js"],
      icon: Brain,
    },
    {
      title: "Corporate Website Redesign",
      category: "web",
      description: "Complete website overhaul for a Fortune 500 company with modern design and improved UX.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop",
      tags: ["React", "Tailwind", "SEO"],
      icon: Code,
    },
    {
      title: "Restaurant Ordering System",
      category: "mobile",
      description: "Mobile app and web dashboard for restaurant orders, reservations, and delivery tracking.",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&h=600&fit=crop",
      tags: ["Flutter", "PostgreSQL", "Stripe"],
      icon: Smartphone,
    },
    {
      title: "Social Media Campaign",
      category: "marketing",
      description: "Comprehensive digital marketing campaign that increased client engagement by 300%.",
      image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&h=600&fit=crop",
      tags: ["Social Media", "Analytics", "Content"],
      icon: Video,
    },
    {
      title: "Predictive Analytics Dashboard",
      category: "ai",
      description: "Real-time analytics platform with AI-powered predictions for business intelligence.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop",
      tags: ["Python", "TensorFlow", "React"],
      icon: Brain,
    },
    {
      title: "Video Production Suite",
      category: "marketing",
      description: "Series of promotional videos and product demonstrations for tech startup launch.",
      image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800&h=600&fit=crop",
      tags: ["Video Editing", "Motion Graphics", "After Effects"],
      icon: Video,
    },
    {
      title: "Healthcare Portal",
      category: "web",
      description: "Secure patient portal with appointment scheduling, medical records, and telemedicine features.",
      image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=600&fit=crop",
      tags: ["HIPAA", "Vue.js", "Security"],
      icon: Code,
    },
  ];

  const filteredProjects = activeFilter === "all"
    ? projects
    : projects.filter(project => project.category === activeFilter);

  return (
    <div>
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Portfolio</h1>
            <p className="text-xl text-blue-100">
              Explore our diverse range of successful projects across web development, mobile apps, AI solutions, and digital marketing.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 bg-white sticky top-16 z-40 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveFilter(category.id)}
                className={`px-6 py-2 rounded-full font-medium transition-all ${
                  activeFilter === category.id
                    ? "bg-blue-600 text-white shadow-md"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, index) => (
              <div
                key={index}
                className="group bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200 hover:shadow-xl transition-all duration-300"
              >
                <div className="relative overflow-hidden aspect-video">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="absolute bottom-4 right-4">
                      <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                        <ExternalLink className="w-5 h-5 text-blue-600" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center space-x-2 mb-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                      <project.icon className="w-4 h-4 text-blue-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">{project.title}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Have a Project in Mind?</h2>
          <p className="text-xl text-gray-600 mb-8">
            Let's bring your vision to life with our expertise and innovative solutions
          </p>
          <a
            href="/contact"
            className="inline-flex items-center px-8 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Start Your Project
          </a>
        </div>
      </section>
    </div>
  );
}
