import { Code, Smartphone, Cloud, Brain, Sparkles, TrendingUp, Megaphone, Target, Video, Film, Edit3, Palette } from "lucide-react";
import { Link } from "react-router";

export function Services() {
  const services = [
    {
      id: "software",
      icon: Code,
      title: "Software Development",
      description: "Comprehensive software solutions tailored to your business needs",
      features: [
        { icon: Code, name: "Web Development", detail: "Responsive, scalable web applications using modern frameworks" },
        { icon: Smartphone, name: "Mobile Development", detail: "Native and cross-platform mobile apps for iOS and Android" },
        { icon: Cloud, name: "SaaS Solutions", detail: "Cloud-based software as a service platforms" },
      ],
      color: "blue",
    },
    {
      id: "ai",
      icon: Brain,
      title: "AI Solutions & Automation",
      description: "Cutting-edge artificial intelligence to transform your business",
      features: [
        { icon: Brain, name: "AI Integration", detail: "Custom AI models and machine learning solutions" },
        { icon: Sparkles, name: "Content Generation", detail: "Automated content creation using advanced AI" },
        { icon: TrendingUp, name: "Process Automation", detail: "Intelligent automation for repetitive tasks" },
      ],
      color: "purple",
    },
    {
      id: "marketing",
      icon: Megaphone,
      title: "Digital Marketing",
      description: "Data-driven marketing strategies that deliver results",
      features: [
        { icon: Target, name: "SEO & SEM", detail: "Search engine optimization and marketing campaigns" },
        { icon: TrendingUp, name: "Social Media", detail: "Social media strategy and management" },
        { icon: Megaphone, name: "Content Marketing", detail: "Engaging content that drives conversions" },
      ],
      color: "pink",
    },
    {
      id: "production",
      icon: Video,
      title: "Post Production Services",
      description: "Professional video editing and post-production excellence",
      features: [
        { icon: Film, name: "Video Editing", detail: "Professional editing for all types of video content" },
        { icon: Edit3, name: "Color Grading", detail: "Expert color correction and grading services" },
        { icon: Palette, name: "Motion Graphics", detail: "Dynamic animations and visual effects" },
      ],
      color: "indigo",
    },
  ];

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; text: string; border: string; lightBg: string }> = {
      blue: { bg: "bg-blue-600", text: "text-blue-600", border: "border-blue-600", lightBg: "bg-blue-50" },
      purple: { bg: "bg-purple-600", text: "text-purple-600", border: "border-purple-600", lightBg: "bg-purple-50" },
      pink: { bg: "bg-pink-600", text: "text-pink-600", border: "border-pink-600", lightBg: "bg-pink-50" },
      indigo: { bg: "bg-indigo-600", text: "text-indigo-600", border: "border-indigo-600", lightBg: "bg-indigo-50" },
    };
    return colors[color] || colors.blue;
  };

  return (
    <div>
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl text-blue-100">
              Comprehensive technology solutions designed to accelerate your business growth and digital transformation.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-24">
            {services.map((service, index) => {
              const colors = getColorClasses(service.color);
              return (
                <div
                  key={service.id}
                  id={service.id}
                  className={`scroll-mt-20 ${index % 2 === 1 ? "bg-gray-50" : ""} -mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8 py-16 rounded-2xl`}
                >
                  <div className="grid md:grid-cols-2 gap-12 items-center">
                    <div className={index % 2 === 1 ? "md:order-2" : ""}>
                      <div className={`w-16 h-16 ${colors.lightBg} rounded-2xl flex items-center justify-center mb-6`}>
                        <service.icon className={`w-8 h-8 ${colors.text}`} />
                      </div>
                      <h2 className="text-3xl font-bold text-gray-900 mb-4">{service.title}</h2>
                      <p className="text-xl text-gray-600 mb-8">{service.description}</p>
                      <Link
                        to="/contact"
                        className={`inline-flex items-center px-6 py-3 ${colors.bg} text-white rounded-lg font-semibold hover:opacity-90 transition-opacity`}
                      >
                        Get Started
                      </Link>
                    </div>
                    <div className={index % 2 === 1 ? "md:order-1" : ""}>
                      <div className="space-y-6">
                        {service.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                            <div className="flex items-start">
                              <div className={`w-12 h-12 ${colors.lightBg} rounded-lg flex items-center justify-center mr-4 flex-shrink-0`}>
                                <feature.icon className={`w-6 h-6 ${colors.text}`} />
                              </div>
                              <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-1">{feature.name}</h3>
                                <p className="text-gray-600">{feature.detail}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Business?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Let's discuss how our services can help you achieve your business goals
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/schedule"
              className="inline-flex items-center justify-center px-8 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Schedule a Meeting
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center justify-center px-8 py-3 bg-transparent border-2 border-white text-white rounded-lg font-semibold hover:bg-white hover:text-gray-900 transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
