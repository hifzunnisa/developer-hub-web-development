import { createBrowserRouter } from "react-router";
import { RootLayout } from "./components/RootLayout";
import { Home } from "./pages/Home";
import { About } from "./pages/About";
import { Services } from "./pages/Services";
import { Portfolio } from "./pages/Portfolio";
import { Contact } from "./pages/Contact";
import { MeetingScheduler } from "./pages/MeetingScheduler";
import { Blog } from "./pages/Blog";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Home },
      { path: "about", Component: About },
      { path: "services", Component: Services },
      { path: "portfolio", Component: Portfolio },
      { path: "contact", Component: Contact },
      { path: "schedule", Component: MeetingScheduler },
      { path: "blog", Component: Blog },
      { path: "*", Component: NotFound },
    ],
  },
]);
